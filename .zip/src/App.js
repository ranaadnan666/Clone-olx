import React from 'react'
import SetRoute from './routing/SetRoute'
import "./App.css"
const App = () => {
  return (
    <>
<SetRoute/>
    </>
  )
}

export default App