import React from 'react'
import Home from '../../components/home/Home'

const MainHome = () => {
  return (
    <div><Home/></div>
  )
}

export default MainHome