import React from 'react'
import { Routes, Route } from "react-router-dom"
import ScrollToTop from './Use'
import Header from '../components/navbar/Header'
import Navbar from '../components/navbar/Navbar'
import MainHome from '../pages/home/Index'

const SetRoute = () => {
  return (
    <div>
        <ScrollToTop>
            <Header/>
            <Navbar/>
        <Routes>
        <Route path="/home" element={ <MainHome/> } />
   
      </Routes>
    </ScrollToTop>
    </div>
  )
}

export default SetRoute